# class Node:
    ## WRITE NODE CONSTRUCTOR HERE ##
    #                               #
    #                               #
    #                               #
    #                               #
    #################################
        

# class BinarySearchTree:
    ## WRITE BST CONSTRUCTOR HERE ##
    #                              #
    #                              #
    #                              #
    #                              #
    ################################




my_tree = BinarySearchTree()

print(my_tree.root)


 
"""
    EXPECTED OUTPUT:
    ----------------
    None

"""