
## WRITE MERGE FUNCTION HERE ##
#                             #
#                             #
#                             #
#                             #
############################### 




# MERGE REQUIRES TWO SORTED LISTS:
print(merge([1,2,7,8], [3,4,5,6]))



"""
    EXPECTED OUTPUT:
    ----------------
    [1, 2, 3, 4, 5, 6, 7, 8]
 """